package com.simplistic.anotherbassboosterpro;

import android.content.Context;
import android.graphics.Canvas;
import androidx.appcompat.widget.AppCompatSeekBar;
import android.util.AttributeSet;

public class VerticalSeekBar extends AppCompatSeekBar {
	VerticalSeekBar verticalSeekBar = this;
	public VerticalSeekBar(Context context) {
		super(context);
	}

	public VerticalSeekBar(Context context, AttributeSet attributeSet) {
		super(context, attributeSet);
	}

	public VerticalSeekBar(Context context, AttributeSet attributeSet, int n) {
		super(context, attributeSet, n);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.rotate((float) -90.0);
		canvas.translate(((-this.getHeight())), (float) 0.0);
		
		super.onDraw(canvas);
	}

	@Override
	protected void onMeasure(int n, int n2) {
		
		synchronized (verticalSeekBar) {
			super.onMeasure(n2, n);
			this.setMeasuredDimension(getMeasuredHeight(), getMeasuredWidth());
			return;
		}
	}

	@Override
	protected void onSizeChanged(int n, int n2, int n3, int n4) {
		super.onSizeChanged(n2, n, n4, n3);
	}

	/*
	 * Enabled aggressive block sorting Enabled unnecessary exception pruning
	 */
	
}
